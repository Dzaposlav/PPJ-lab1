import pickle
import sys

def epsilon_okruzenje(automat, stanjaX):
	stog = []
	stanjaY = []

	stog = stanjaX[:]
	stanjaY = stanjaX[:]

	while len(stog)>0:
		stanje = stog.pop()
		string_stanje = str(stanje)
		if string_stanje+'|$$' in automat:
			for i in automat[string_stanje+'|$$']:
				if i not in stanjaY:
					stanjaY.append(i)
					stog.append(i)
	return stanjaY

def prijelaz(automat, stanjaX, znak):
	stanjaY = []

	for i in stanjaX:
		if str(i)+'|'+znak in automat:
			for j in automat[str(i)+'|'+znak]:
				if j not in stanjaY:
					stanjaY.append(j)
	return stanjaY

def konacna_stanja(akcije, stanja):
	konStanja = []
	for i in stanja:
		if i in akcije:
			konStanja.append(i)
	return konStanja

def obavi_akciju(stanje):
	global akcije
	global br_redaka
	global zavrsetak
	global LAstanje
	global pocetak
	global posljednji

	temp = akcije[stanje][0]

	trenutniRed = br_redaka


	if len(akcije[stanje]) > 1:
		for i in akcije[stanje][1:]:
			if 'NOVI_REDAK' in i:
				br_redaka = br_redaka + 1
			elif 'VRATI_SE' in i:
				index = int(i.split(' ')[1])
				zavrsetak = pocetak + index
				posljednji = zavrsetak
			elif 'UDJI_U_STANJE' in i:
				LAstanje = i.split(' ')[1]
			else:
				pass

	if temp == '-':
		pass
	else:
		print(temp+' '+str(trenutniRed)+' '+ulaz[pocetak:posljednji])





automat = pickle.load(open("automat.p", "rb"))
stanja_analizatora = pickle.load(open("stanja.p", "rb"))
akcije = pickle.load(open("akcije.p", "rb"))


ulaz = sys.stdin.read()

pocetak = 0
zavrsetak = 0
posljednji = 0
br_redaka = 1

LAstanje = stanja_analizatora['pocetno']

R = []

while zavrsetak < len(ulaz):
	izraz = 0
	R = stanja_analizatora[LAstanje][:]
	R = epsilon_okruzenje(automat, R)	
	while R:
		Fstanja = konacna_stanja(akcije, R)
		if Fstanja:
			izraz = min(Fstanja)
			posljednji = zavrsetak
			if zavrsetak == len(ulaz):
				break
			znak = ulaz[zavrsetak]
			zavrsetak = zavrsetak + 1
			R = prijelaz(automat, R, znak)
			R = epsilon_okruzenje(automat, R)

		else:
			if zavrsetak == len(ulaz):
				break
			znak = ulaz[zavrsetak]
			zavrsetak = zavrsetak + 1
			R = prijelaz(automat, R, znak)
			R = epsilon_okruzenje(automat, R)

	if izraz == 0:
		sys.stderr.write(ulaz[pocetak])
		pocetak = pocetak + 1
		zavrsetak = pocetak
	else:
		obavi_akciju(izraz)
		pocetak=posljednji
    	zavrsetak=pocetak


